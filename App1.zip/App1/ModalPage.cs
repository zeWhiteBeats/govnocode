﻿using System;

namespace Navigation
{
    public class ModalPage : ContentPage
    {
        public ModalPage() 
        {
            Title = "Modal Page";
            Button backButton = new Button
            {
                Text = "Back",
                HorizontalOptons = LayoutOptions.Center,
                VerticalOptions = LayoutOptions.Center
            };
            backButton.Clicked += BackButton_Click;

            Content = backButton
        }
        private async void BackButton_Click(object sender, EventArgs e)
        {
            await Navigation.popModalAsync();
        }
    }
}