﻿
using Xamarin.Forms;

namespace Navigation
{
    public partial class CommonPage : ContentPage
    {
        public CommonPage()
        {
            //InitializeComponent();
            Title = "Страница 1";
            Button backButton = new Button
            {
                Text = "Назад",
                HorizontalOptions = LayoutOptions.Center,
                VerticalOptions = LayoutOptions.Center
            };
            backButton.Clicked += BackButton_Click;
            Content = backButton;
        }
        private async void BackButton_Click(object sender, EventArgs e)
        {
            await Navigation.PopAsync();
        }
    }
}
